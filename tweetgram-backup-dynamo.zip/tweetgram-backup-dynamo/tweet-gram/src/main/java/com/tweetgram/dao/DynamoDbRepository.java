package com.tweetgram.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBScanExpression;
import com.tweetgram.model.Login;
import com.tweetgram.model.TweetList;

@Repository
public class DynamoDbRepository {

	@Autowired
	private DynamoDBMapper mapper;
	
	public boolean register(Login login) {
		mapper.save(login);
		return true;
	}
	
	public boolean updateUser(Login login) {
		Login log =mapper.load(Login.class,login.getEmail());
		System.out.println(log);
		if(log != null && login.getPassword().equals(log.getPassword()) && login.getEmail().equals(log.getEmail())) {
			return true;
		} else {
			return false;
		}
	}
	
	
	public List<TweetList> viewAllTweet() {
//				DynamoDBMapperConfig mapperConfig = new DynamoDBMapperConfig.Builder().withTableNameOverride(DynamoDBMapperConfig.TableNameOverride.withTableNameReplacement("tweet")).build();
//				DynamoDBMapper mapper = new DynamoDBMapper(client, mapperConfig);

				DynamoDBScanExpression scanExpression = new DynamoDBScanExpression();
				List < TweetList > scanResult = mapper.scan(TweetList.class, scanExpression);
				return scanResult;
	}
	
	public boolean postTweet(TweetList tweetList) {
		mapper.save(tweetList);
		return true;
		
	}
}
