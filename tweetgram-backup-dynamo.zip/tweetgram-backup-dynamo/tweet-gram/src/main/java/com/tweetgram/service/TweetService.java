//package com.tweetgram.service;
//
//import java.util.List;
//
//import org.springframework.stereotype.Service;
//
//import com.tweetgram.model.TweetList;
//
//@Service
//public interface TweetService {
//public  boolean postTweet(TweetList tweet);
//public 	List<TweetList> viewAllTweet();
////public boolean deleteTweet()
//}
//
