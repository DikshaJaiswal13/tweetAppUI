package com.tweetgram.model;

import java.io.Serializable;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBAttribute;

//import org.springframework.data.cassandra.core.cql.PrimaryKeyType;
//import org.springframework.data.cassandra.core.mapping.PrimaryKeyClass;
//import org.springframework.data.cassandra.core.mapping.PrimaryKeyColumn;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBDocument;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBHashKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBRangeKey;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

//@PrimaryKeyClass
//@NoArgsConstructor
//@Getter
//@Setter
@DynamoDBDocument
public class TweetId implements Serializable {
	//@PrimaryKeyColumn(type = PrimaryKeyType.PARTITIONED)
	String email;
	//@PrimaryKeyColumn(name = "tweet_text", ordinal = 1, type = PrimaryKeyType.PARTITIONED)
	String tweetText;
	
	@DynamoDBAttribute
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	
	@DynamoDBAttribute
	public String getTweetText() {
		return tweetText;
	}

	public void setTweetText(String tweetText) {
		this.tweetText = tweetText;
	}
}
