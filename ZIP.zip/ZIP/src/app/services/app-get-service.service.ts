import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AppGetServiceService {

  constructor(private http: HttpClient) { }

  public loginUser(req) {
    return this.http.get<any>(`http://localhost:8081/loginUser`,req);
  }

  public viewAllTweet(reqObj) {
    return this.http.get<any>(`http://localhost:8081/viewAllTweet`);
  }
}
