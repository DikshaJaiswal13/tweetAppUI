import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AppPostServiceService {

  constructor(private http: HttpClient) { }

  public saveUser(reqObj) {
    return this.http.post<any>(`http://localhost:8081/saveUser`,reqObj);
  }

  public loginUser(reqObj) {
    return this.http.post<any>(`http://localhost:8081/loginUser`,reqObj);
  }

  public postTweet(reqObj) {
    return this.http.post<any>(`http://localhost:8081/postTweet`,reqObj);
  }

  public updateUser(reqObj) {
    return this.http.put<any>(`http://localhost:8081/updateUser`,reqObj);
  }
}
