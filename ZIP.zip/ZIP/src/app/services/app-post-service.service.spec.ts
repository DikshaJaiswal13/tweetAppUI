import { TestBed } from '@angular/core/testing';

import { AppPostServiceService } from './app-post-service.service';

describe('AppPostServiceService', () => {
  let service: AppPostServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AppPostServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
