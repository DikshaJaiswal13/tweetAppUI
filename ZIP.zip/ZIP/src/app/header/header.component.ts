import { Component, OnInit } from '@angular/core';
import { Router, NavigationStart } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {

  public pageUrl: any;

  constructor(public router: Router) {
    this.router.events.subscribe((event) => {
      if (event instanceof NavigationStart) {
        // Show loading indicator
        this.pageUrl = event.url;
        // setTimeout(() => {
        //   this.getLoginUser();
        // }, 10);
      }
    });
  }


  ngOnInit(): void {
  }

  public logout(): any {
    localStorage.removeItem('currentUser');
    this.router.navigate(['/']);
  }

  public allTweets(): any{
    this.router.navigate(['/allTweets']);
  }

}
