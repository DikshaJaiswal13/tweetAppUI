import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router, NavigationStart } from '@angular/router';

@Component({
  selector: 'app-alltweet',
  templateUrl: './alltweet.component.html',
  styleUrls: ['./alltweet.component.scss']
})
export class AlltweetComponent implements OnInit {

  public pageUrl: any;
  public tweetList = [];
  public currentUser;

  constructor(public router: Router, private httpClient: HttpClient) {
    this.router.events.subscribe((event) => {
      if (event instanceof NavigationStart) {
        // Show loading indicator
        this.pageUrl = event.url;
        // setTimeout(() => {
        //   this.getLoginUser();
        // }, 10);
      }
    });
  }

  ngOnInit(): void {
    this.httpClient.get('./../assets/allTweetsResponse.json').subscribe(data => {
      this.tweetList = data['success']['data']['searchResults'];
      // if (data.type === 'Success') {
       // const { searchResults } = data.response;
    });
    this.currentUser = JSON.parse(localStorage.getItem('currentUser'));
  }

}
