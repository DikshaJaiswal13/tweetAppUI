import { Component, OnInit, ViewEncapsulation, ChangeDetectionStrategy, Input, Output, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
// import { DataServiceService } from '../shared/services/data-service.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class LoginComponent implements OnInit {

  loginForm: FormGroup;
  submitted = false;
  // @Output() loginId: EventEmitter<string> = new EventEmitter();

  // constructor(private router: Router, private dataService: DataServiceService,private formBuilder: FormBuilder){}
  constructor(private router: Router, private formBuilder: FormBuilder){}

  ngOnInit(): void {
    this.loginForm = this.formBuilder.group({
      userId: ['', Validators.required],
      password: ['', Validators.required],
    });
    localStorage.removeItem('currentUserData');
  }

  public signUp(): any {
    this.router.navigate(['/signup']);
  }

  get formFields(): any { return this.loginForm.controls; }

  onClickSubmit(formData): any {
    if (this.loginForm.controls.userId.value === '@jewel_saha' && this.loginForm.controls.password.value === 'admin') {
      this.router.navigate(['/tweet']);
      localStorage.setItem('currentUser', JSON.stringify(this.loginForm.controls.userId.value));
      // this.loginId.emit(this.loginForm.controls.userId.value);
    }
    if (this.loginForm.invalid) {
      this.submitted = true;
      return;
    }
    // this.alertService.clear();
    // this.Auth.authorizeUser(formData);
  }

  public login() {
    if (this.loginForm.controls.userId.value === '@jewel_saha' && this.loginForm.controls.password.value === 'admin') {
      this.router.navigate(['/tweet']);
      localStorage.setItem('currentUser', JSON.stringify(this.loginForm.controls.userId.value));
      // this.loginId.emit(this.loginForm.controls.userId.value);
    }
    if (this.loginForm.invalid) {
      this.submitted = true;
      return;
    }
  }


}
