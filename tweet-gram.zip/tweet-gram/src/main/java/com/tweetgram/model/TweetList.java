
package com.tweetgram.model;

import java.io.Serializable;

import org.springframework.data.cassandra.core.mapping.Column;
import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.Table;

import lombok.NoArgsConstructor;

@Table(value="tweet")
@NoArgsConstructor
public class TweetList implements Serializable{
	@PrimaryKey
	private TweetId tweetId;
	@Column(value = "login_status")
	private String loginStatus;

	public TweetId getTweetId() {
		return tweetId;
	}

	public void setTweetId(TweetId tweetId) {
		this.tweetId = tweetId;
	}

	public String getLoginStatus() {
		return loginStatus;
	}

	public void setLoginStatus(String loginStatus) {
		this.loginStatus = loginStatus;
	}

	@Override
	public String toString() {
		return "TweetList [tweetId=" + tweetId + ", loginStatus=" + loginStatus + "]";
	}

}
